#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<pthread.h>

pthread_mutex_t lock;
int len;
int max, min;
double avg;
int *arr;

void *average(void *arg)
{
    pthread_mutex_lock(&lock);
    int sum = 0;
    int *arr;
    arr = arg;
    for (int i = 0; i < len; i++)
    {
        sum += arr[i];
    }
    avg = sum / len;
    printf("The average value: %f \n", avg);
    pthread_mutex_unlock(&lock);
    return 0;
}

void *maximum(void *arg)
{
    pthread_mutex_lock(&lock);
    int *arr;
    arr = arg;
    max = arr[0];
    for (int i = 0; i < len; i++)
    {
        if (arr[i] > max)
        {
            max = arr[i];
        }
    }
    printf("The maximum value: %d \n", max);
    pthread_mutex_unlock(&lock);
    return 0;
}

void *minimum(void *arg)
{
    pthread_mutex_lock(&lock);
    int *arr;
    arr = arg;
    min = arr[0];
    for (int i = 0; i < len; i++)
    {
        if (arr[i] < min)
        {
            min = arr[i];
        }
        
    }
    printf("The minimum value: %d \n", min);
    pthread_mutex_unlock(&lock);
    return 0;
}


int main(int argc, char *argv[])
    {
         if (argc < 2) {
	        fprintf(stderr, "Usage: Stat_Values list of integers\n");
	        exit(1);
        }
        
       //int i;
        --argc;
        ++argv;
        arr = calloc(argc, sizeof(int));
        for (int i = 0; i < argc; i++)
        {
            arr[i] = atoi(argv[i]);
            len++;
        }


        pthread_t p1, p2, p3;

        if (pthread_mutex_init(&lock, NULL) != 0)
        {
            printf("Mutex init failed \n");
            return 1;
        }
        
        // pthread_create (Thread, attr, start_routine, arg);
        pthread_create(&p1, NULL, average, arr);
        pthread_create(&p2, NULL, minimum, arr);
        pthread_create(&p3, NULL, maximum, arr);
        
        pthread_join(p1, NULL);
        pthread_join(p2, NULL);
        pthread_join(p3, NULL);
        
        return 0;
    }