#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<pthread.h>

int n;

void *isPrime(void *arg) {
    n = (int) arg;
    int x = 0;
    int count;
    if (n <= 1)
    {
        return 0;
    }
    
    for (int j = 2; j <= n; j++)
    {
        count = j;
        x = 0;
        for (int i = 2; i < count; i++)
        {
            if (count % i == 0) 
            {
                x++;
            }
        }
        if (x == 0)
        {
            printf("%d ", count);
        }
    }
    return 0;
}

int main(int argc, char *argv[])
    {
        // pthread_create (Thread, attr, start_routine, arg);
        if (argc != 2) {
	        fprintf(stderr, "Usage: Prime_Numbers positive integer\n");
	        exit(1);
        }
        if (argv[1] < 0)
        {
            fprintf(stderr, "Usage: Prime_Numbers positive integer\n");
            exit(1);
        }
        
        n = atoi(argv[1]);
        
        pthread_t p1;
        
        pthread_create(&p1, NULL, isPrime, (void *) n);
        
        pthread_join(p1, NULL);
        
        
        return 0;
    }